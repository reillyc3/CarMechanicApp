package com.itmd515.auth.service;

import com.itmd515.auth.model.User;

public interface UserService {
    void save(User user);

    User findByUsername(String username);
}
